﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class quit : MonoBehaviour
{

    public void quitGame()
    {
        SceneManager.LoadScene("menuScreen");
    }
}
