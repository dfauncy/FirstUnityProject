﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour {

	public void switchToHighScoreScene()
    {
        Debug.Log("HighScore Scene");
        SceneManager.LoadScene("highScoreScene");
    }

    public void startGame()
    {
        SceneManager.LoadScene("ClickerScoreSystem");
    }

}

public class CompleteCameraController : MonoBehaviour
{

    public GameObject player;      

    private Vector3 offset;        
    void Start()
    {
       
        offset = transform.position - player.transform.position;
    }

   
    void LateUpdate()
    {
       
        transform.position = player.transform.position + offset;
    }
}