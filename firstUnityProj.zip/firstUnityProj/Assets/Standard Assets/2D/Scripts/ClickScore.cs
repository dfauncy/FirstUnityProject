﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ClickScore : MonoBehaviour {
	Text text;
	int score = 0;
	// Use this for initialization
	void Start () {
		text = transform.Find("Text").GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.Space)) {
			score++;
			text.text = "SCORE: "+score;
		}
            
    }
}
