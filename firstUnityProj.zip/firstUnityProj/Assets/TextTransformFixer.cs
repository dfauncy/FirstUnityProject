﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TextTransformFixer : MonoBehaviour {

	Text text;
	Vector3 savedAbsolutePosition;

	void Start () {
		text = transform.Find ("Text").GetComponent<Text>();
		savedAbsolutePosition = text.transform.position;
	}

	
	void Update () {
		FixTextPosition();
	}

	void FixTextPosition(){

		text.transform.rotation = Quaternion.identity;
		text.transform.position = savedAbsolutePosition;
	}
}

