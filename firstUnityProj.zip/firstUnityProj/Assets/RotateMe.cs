﻿using UnityEngine;
using System.Collections;

public class RotateMe : MonoBehaviour {

	void Update () {
		transform.Rotate(new Vector3(0f,0f, 15f * Time.deltaTime));
	}
}
